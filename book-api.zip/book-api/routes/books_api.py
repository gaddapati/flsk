from flask import Blueprint, jsonify, make_response
from flask import request
from db_helper import DBHelper


bp = Blueprint('books_api', __name__)

def get_blueprint():
    return bp

@bp.route('/api/books', methods=['GET'])
def get_books():
    data = DBHelper.get_all_books()
    books = []
    for doc in data :
        doc['_id'] = str(doc['_id'])
        books.append(doc)
    return make_response(jsonify(books), 200)

@bp.route('/api/books/<id>', methods=['GET'])
def get_book(id):
    book = DBHelper.get_book_by_id(id)
    if book:
        book['_id'] = str(book['_id'])
        return make_response(jsonify(book), 200)
    else:
        return make_response(jsonify({'message' : f'Book with id {id}'}), 200)
    
@bp.route('/api/books', methods=['POST'])
def add_book():
    book = request.get_json()
    result = DBHelper.add_book(book)
    return make_response(jsonify,({'message' : f' Add Book {book}'}), 200)