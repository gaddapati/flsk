# from flask import Flask, jsonify
# import os
# from dotenv import load_dotenv
# #Load environment variables from .env file
# load_dotenv()
# app = Flask(__name__)

# @app.route('/api/hello', methods=['GET'])
# def get_hello():
#     return jsonify({ 'message':'Hello World!'})

# @app.route('/api/hello/<name>', methods=['GET'])
# def get_hello_name(name):
#     return jsonify({'message':f'Hello {name}!'})

# port = os.environ['FLASK_PORT']

# if __name__ =='__main__':
#     app.run(debug = True, host='0.0.0.0', port=port)
from flask import Flask,jsonify,make_response
import os
from dotenv import load_dotenv
from routes.books_api import get_blueprint
from db_helper import DBHelper
from flask_cors import CORS
 
load_dotenv()
DBHelper.configure_mongo()
 
app= Flask(__name__)   #instance
CORS(app)
#Middleware
#Execute the method before each request
@app.before_request
def before():
    print("Hi, I am from before_request()")

#Error Handleer
@app.errorhandler(404)
def page_not_found(e):
    return make_response(jsonify({'message':'404 Not Found'}), 404)

#Configure the blueprint
app.register_blueprint(get_blueprint())





 
# @app.route('/api/hello',methods=['GET'])
# def get_hello():
#     return make_response(jsonify({ 'message' : 'Hello world'}), 200)
 
 
# @app.route('/api/hello/<name>',methods=['GET'])
# def get_hello_name(name):
#     return make_response(jsonify({'message' : f'Hello{name}'}), 200)
 
 
 
 
port= os.getenv('FLASK_PORT')
 
if __name__=="__main__":
    app.run(debug=True,host='0.0.0.0',port=port)